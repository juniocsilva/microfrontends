import { Compiler, Component, NgZone, OnChanges, OnInit, SystemJsNgModuleLoader } from '@angular/core';
import { EventManager } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'mf-simtr-footer',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnChanges{
  title = 'mf-simtr-footer';
  public token
 

  constructor(private router: Router, private route: ActivatedRoute, private ngZone: NgZone) {

  }
  ngOnInit() {
      const loader = new SystemJsNgModuleLoader(new Compiler());
      const xpto = loader.load("http://localhost:8500/simtr-mf-simtr-shared.js")
      .then((resp:any) =>  {
        resp.moduleType.prototype.getToken().subscribe(tkn => {
          
          this.token = tkn
          console.log('FOOTER',this.token)
        })
      })
  }

  ngOnChanges() {
    console.log('FOOTER ONCHANGES',this.token)
  }

 
}
