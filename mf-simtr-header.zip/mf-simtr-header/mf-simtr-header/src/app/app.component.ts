import { ApplicationRef, Compiler, Component, NgZone, SystemJsNgModuleLoader } from '@angular/core';

@Component({
  selector: 'mf-simtr-header',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'mf-simtr-header';
  shared
  xpto:any
  funcoes
  token
  constructor(private ngZone: NgZone, private appRef: ApplicationRef) {
  }

  ngOnInit() {
      let x = 'testando....'
      const loader = new SystemJsNgModuleLoader(new Compiler());
      this.xpto = loader.load("http://localhost:8500/simtr-mf-simtr-shared.js")
      .then((resp:any) => {
        resp.moduleType.prototype.setToken('VALOR INICIAL')
        resp.moduleType.prototype.getToken().subscribe(tkn => {
          this.token = tkn
          console.log('HEADER', this.token)
          this.appRef.tick()
        })
      })
  }
}
