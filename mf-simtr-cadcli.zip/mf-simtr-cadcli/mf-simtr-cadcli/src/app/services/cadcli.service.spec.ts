import { TestBed } from '@angular/core/testing';

import { CadcliService } from './cadcli.service';

describe('CadcliService', () => {
  let service: CadcliService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CadcliService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
