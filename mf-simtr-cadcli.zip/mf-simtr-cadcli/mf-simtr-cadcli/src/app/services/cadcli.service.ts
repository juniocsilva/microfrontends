import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CadcliService {
  headers: HttpHeaders 
  
  urlBase = environment.apiPath 

  constructor(private http: HttpClient) { }

  getPorId(id:string): Observable<any>  {
    return this.http.get(this.urlBase + "/clientes/"+ id);
  }//FIM METODO

  getPorCpfCnpj(cpfcnpj:string): Observable<any>  {
    return this.http.get(this.urlBase + "/clientes/cpfcnpj/"+ cpfcnpj);
  }//FIM METODO

  patch(cliente): Observable<any>  {
    return this.http.patch(this.urlBase + "/clientes/"+ cliente.id, cliente);
  }//FIM METODO

  post(cliente): Observable<any>  {
    return this.http.post(this.urlBase + "/clientes", cliente);
  }//FIM METODO

  delete(id): Observable<any>  {
    return this.http.delete(this.urlBase + "/clientes/" + id);
  }//FIM METODO

}
