import { Compiler, Component, NgZone, SystemJsNgModuleLoader } from '@angular/core';
import { CadcliService } from './services/cadcli.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
declare var $:any;
@Component({
  selector: 'mf-simtr-cadcli',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'mf-simtr-cadcli';
  public id = '';
  public cpfCnpj = '';
  public nome = '';
  public endereco = '';
  public patrimonio = '';
  public renda = '';
  public lblBtnIncAlt = "Incluir"
  public encontrou = false;
  public mensagem = ''  ;
  public tipoMensagem = 'primary';
  public exibirMensagem = false;
  public xpto
  public token = ''
  public shared

  constructor(private cadCliService: CadcliService, 
    private spinner: NgxSpinnerService, private ngZone: NgZone) {

     

        const loader = new SystemJsNgModuleLoader(new Compiler());
        this.xpto = loader.load("http://localhost:8500/simtr-mf-simtr-shared.js")
        .then((resp:any) => {
          this.shared = resp
          resp.moduleType.prototype.getToken().subscribe(tkn => {
          
            this.token = tkn
            console.log('CADCLI',this.token)
            
          })
        })
     
       
  }
  pesquisarCliente() {
    if (this.cpfCnpj == "") {
      return
    }
    this.spinner.show()
    this.exibirMensagem = false
    this.cadCliService.getPorCpfCnpj(this.cpfCnpj).subscribe(dados => {
      
      if (dados) {
        this.id = dados.id
        this.cpfCnpj = dados.nuCpfCnpj
        this.nome = dados.nome
        this.endereco = dados.endereco
        this.patrimonio = dados.patrimonio
        this.renda = dados.renda
        this.lblBtnIncAlt = "Alterar"
        this.encontrou = true;
        this.spinner.hide();
      } 
      
    }, error => {
      if (error.status == 404) {
        this.nome = ""
        this.endereco = ""
        this.patrimonio = ""
        this.renda = ""
        this.lblBtnIncAlt = "Incluir"
        this.mensagem = 'Registro não encontrado! Para incluir um novo registro informe os dados e clique no botão Incluir.'
        this.tipoMensagem = 'danger'
        this.retornarMensagem(this.mensagem, this.tipoMensagem)
        this.spinner.hide();
        this.encontrou = true;
        $('#nome').focus();
      } else {
        this.mensagem = "Não foi possível pesquisar o registro(" + error.status + ")"
        this.tipoMensagem = 'danger'
        this.retornarMensagem(this.mensagem, this.tipoMensagem)
        
      }
    })
  }
  
  limparTela(form) {
    form.control.markAsPristine();
    form.control.markAsUntouched();
    this.cpfCnpj = ""
    this.nome = ""
    this.endereco = ""
    this.patrimonio = ""
    this.renda = ""
    this.encontrou = false;
    this.lblBtnIncAlt = "Incluir"
    this.mensagem = ''
    this.tipoMensagem = 'info'
    this.exibirMensagem = false
   $('#cpfnpj').focus();
   
  }

  excluir(form) {
    this.spinner.show()
  
    this.cadCliService.delete(this.id).subscribe(() => {
      this.limparTela(form);
      this.mensagem = "Registro Excluído com Sucesso."
      this.retornarMensagem(this.mensagem, 'info')
      $('#modalConfirmaExclusao').modal('toggle');
      this.spinner.hide();
      
      
    }, error => {
      console.log(error)
      this.mensagem = "Não foi possível excluir este registro (" + error.status + ")"
      this.retornarMensagem(this.mensagem, 'error')
      $('#modalConfirmaExclusao').modal('toggle');
      this.spinner.hide();
      $('#cpfnpj').focus();
    });

 
  }

  incluirAlterar(form) {
    this.shared.moduleType.prototype.setToken(this.token)
    let cliente = {
      "id": this.id,
      "nuCpfCnpj": this.cpfCnpj,
      "nome": this.nome,
      "endereco": this.endereco,
      "renda": this.renda,
      "patrimonio": this.patrimonio
    } 
    this.spinner.show();
    if (this.lblBtnIncAlt == "Alterar") {
    
      this.cadCliService.patch(cliente).subscribe(dados => {
        if (dados) {
         this.limparTela(form);
         this.mensagem = "Registro alterado com sucesso."
         this.retornarMensagem(this.mensagem, 'info')
        }
      })
    } else {
      if (this.lblBtnIncAlt == "Incluir") {
        this.cadCliService.post(cliente).subscribe(dados => {
          if (dados) {
            this.limparTela(form);
            this.mensagem = "Registro incluído com sucesso."
            this.retornarMensagem(this.mensagem, 'info')
          }
        })
      }
    }
    this.spinner.hide();
  }

  private retornarMensagem(mensagem, tipo) {
    this.mensagem = mensagem
    this.tipoMensagem = tipo
    this.exibirMensagem = true
    this.spinner.hide();
  }
}
