import { ApplicationRef, Compiler, Component, NgZone, SystemJsNgModuleLoader } from '@angular/core';

@Component({
  selector: 'mf-simtr-rodape',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'mf-simtr-rodape';
  public token = ''
  
  constructor(private zone:NgZone, private appRef: ApplicationRef) {

  }
  
  ngOnInit() {
   

      const loader = new SystemJsNgModuleLoader(new Compiler());
      const xpto = loader.load("http://localhost:8500/simtr-mf-simtr-shared.js")
      .then((resp:any) =>  {
        resp.moduleType.prototype.getToken().subscribe(tkn => {
          
          this.token = tkn
          console.log('RODAPE',this.token)
          this.appRef.tick()
        })
      })
   
  }
}
