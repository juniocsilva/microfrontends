export function teste () {
    return 'teste';
}