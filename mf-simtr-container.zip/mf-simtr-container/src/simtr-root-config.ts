import { registerApplication, start } from "single-spa";


registerApplication({
  name: "@simtr/mf-simtr-header",
  app: () => System.import("@simtr/mf-simtr-header"),
  activeWhen: ["/"]
});

registerApplication({
  name: "@simtr/mf-simtr-cadcli",
  app: () => System.import("@simtr/mf-simtr-cadcli"),
  activeWhen: ["/cadcli"]
});

registerApplication({
  name: "@simtr/mf-simtr-app1",
  app: () => System.import("@simtr/mf-simtr-app1"),
  activeWhen: ["/app1"]
});

registerApplication({
  name: "@simtr/mf-simtr-rodape",
  app: () => System.import("@simtr/mf-simtr-rodape"),
  activeWhen: ["/"]
});




start({
  urlRerouteOnly: true,
});
