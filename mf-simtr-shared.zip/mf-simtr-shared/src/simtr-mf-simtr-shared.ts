// Anything exported from this file is importable by other in-browser modules.
export function publicApiFunction() {}
import { BehaviorSubject, Observable } from "rxjs";

export default class {
    _token = new BehaviorSubject<any>('VALOR INICIAL');
    
    setToken(tkn) {
        if (this._token) {

            this._token.next(tkn);
        } else {
            this._token = new BehaviorSubject<any>('');
            this._token.next(tkn);
        }
    }
    
    getToken(): Observable<any> {
        if (!this._token) {

            this._token = new BehaviorSubject<any>('');
        }
        return this._token.asObservable();
    }  
}